package ePortfolio;

/**
 * This subclass represents a stock investment that is part of a portfolio.
 * It contains the stock's name, symbol, quantity, price, and book value,
 * inherited from the superclass.
 * This class provides methods to access and modify these attributes.
 */
public class Stock extends Investment {

    /**
     * Constructor for creating a new Stock object.
     *
     * @param symbol    the symbol of the stock
     * @param name      the name of the stock
     * @param quantity  the quantity of the stock
     * @param price     the price of the stock
     * @param bookValue the book value of the stock
     */

    public Stock(String name, String symbol, int quantity, double price, double bookValue) {
        super(name, symbol, quantity, price, bookValue);
        calculateBookValue();
    }

    @Override
    public void calculateBookValue() {
        setBookValue(getQuantity() * getPrice() + 9.99);
    }

    @Override
    public double calculatePaymentReceived(int quantitySold) {
        return quantitySold * getPrice() - 9.99; // commission fee for stocks
    }

    @Override
    public double calculateGain(int quantitySold) {
        double payment = calculatePaymentReceived(quantitySold);
        double bookValueSold = (getBookValue() / getQuantity()) * quantitySold;
        return payment - bookValueSold;
    }

    @Override
    public void updatePrice(double newPrice) {
        setPrice(newPrice);
    }

    @Override
    public String toString() {
        return "Stock{" + "symbol='" + getSymbol() + '\'' + ", name='" + getName() + '\'' + ", quantity="
                + getQuantity() + ", price=" + getPrice() + ", bookValue=" + getBookValue() + '}';
    }
}
