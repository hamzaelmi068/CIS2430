package ePortfolio;

/**
 * This class represents a mutual fund investment that is part of a portfolio.
 * It is a subclass and inherits from the Investment superclass.
 * It contains the mutual fund's name, symbol, quantity, price, and book value.
 * This class provides methods to access and modify these attributes.
 */
public class MutualFund extends Investment {

    /**
     * Constructor for creating a new MutualFund object.
     *
     * @param symbol    the symbol of the mutual fund
     * @param name      the name of the mutual fund
     * @param quantity  the quantity of the mutual fund
     * @param price     the price of the mutual fund
     * @param bookValue the book value of the mutual fund
     */
    public MutualFund(String name, String symbol, int quantity, double price, double bookValue) {
        super(name, symbol, quantity, price, bookValue);
        calculateBookValue();
    }

    @Override
    public void calculateBookValue() {
        setBookValue(getQuantity() * getPrice()); // no fee for mutualfunds
    }

    @Override
    public double calculatePaymentReceived(int quantitySold) {
        return quantitySold * getPrice() - 45.00; // redemption fee for mutualfund
    }

    @Override
    public double calculateGain(int quantitySold) {
        double payment = calculatePaymentReceived(quantitySold);
        double bookValueSold = (getBookValue() / getQuantity()) * quantitySold;
        return payment - bookValueSold;
    }

    @Override
    public void updatePrice(double newPrice) {
        setPrice(newPrice);
    }

    @Override
    public String toString() {
        return "MutualFund{" + "symbol='" + getSymbol() + '\'' + ", name='" + getName() + '\'' + ", quantity="
                + getQuantity() + ", price=" + getPrice() + ", bookValue=" + getBookValue() + '}';
    }
}