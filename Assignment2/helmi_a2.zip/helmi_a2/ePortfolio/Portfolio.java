package ePortfolio;

import java.util.Scanner;
import java.util.Set;
import java.util.ArrayList;
import java.io.*;
import java.util.HashMap;
import java.util.HashSet;

/**
 * This class represents a Portfolio that will manage stocks and mutualfunds
 */
public class Portfolio {
    // array list for investments below
    private ArrayList<Investment> investments;
    // using hashmap as an index to to stor the keywords
    private HashMap<String, ArrayList<Integer>> nameIndex;

    // Constructor for objects / Portfolio below
    /**
     * This Constructor for new Portfolio object
     * This initializes investments arraylist and nameindex arraylist for the
     * hashmap
     */
    public Portfolio() {
        investments = new ArrayList<>();
        nameIndex = new HashMap<>();
    }

    // print menu method, to make our main more organized
    private static void printMenu() {
        System.out.println("(Option 1): Buy - Check if the investment exists, update or create new");
        System.out.println("(Option 2): Sell - Check if the investment exists and has enough quantity");
        System.out.println("(Option 3): Update - Go through all investments and update prices ");
        System.out.println("(Option 4): Get Gain - Calculate total gain for all investments");
        System.out.println(
                "(Option 5): Search - Implement search functionality based on symbol, keywords, and price range");
        System.out.println("(Option 6): Exit the program");
        System.out.println("Enter your choice: ");
    }

    // main method, entry point of program, with command loop and menu options
    /**
     * The main method is the entry point for my program.
     * It initializes a new Portfolio and a Scanner for user input.
     * 
     * @param args command-line arguments passed to the program
     */
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage for the program should be: java Portfolio <filename1>");
            return;
        }

        String fileName = args[0];
        Portfolio ePortfolio = new Portfolio();
        Scanner scanner = new Scanner(System.in);

        // loading investments from a file
        ePortfolio.loadFromFile(fileName);

        String userInput;
        boolean shouldExit = false;

        do {
            // printing the menu
            printMenu();
            // scanning the users choice below
            userInput = scanner.nextLine().toLowerCase().trim();

            switch (userInput) {
                case "1":
                case "buy":
                case "b":
                    ePortfolio.buyInvestment(scanner);
                    break;
                case "2":
                case "sell":
                    ePortfolio.sellInvestment(scanner);
                    break;
                case "3":
                case "update":
                case "u":
                    ePortfolio.updateInvestment(scanner);
                    break;
                case "4":
                case "gain":
                case "g":
                    ePortfolio.getGain();
                    break;
                case "5":
                case "search":
                    ePortfolio.searchInvestment(scanner);
                    break;
                case "6":
                case "quit":
                case "q":
                    System.out.println("Exiting program...");
                    shouldExit = true;
                    // saving investments before exiting
                    ePortfolio.saveFromFile(fileName);
                    break;
                default:
                    System.out.println("Invalid choice, please try again");
            }

        } while (!shouldExit);

        // closing the scanner
        scanner.close();
    }

    /**
     * Loads investment data from a specified file and populates the portfolio.
     *
     * @param fileName the name of the file containing investment data
     */
    private void loadFromFile(String fileName) {
        try (Scanner scanner = new Scanner(new File(fileName))) {
            // Initialize variables to store investment attributes
            String type = "";
            String symbol = "";
            String name = "";
            int quantity = 0;
            double price = 0.0, bookValue = 0.0;

            // Read the file line by line
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();

                if (line.contains("=")) {
                    // Split the line into key and value
                    String[] parts = line.split("=");
                    String key = parts[0].trim();
                    // Remove quotes from value
                    String value = parts[1].trim().replace("\"", "").trim();

                    // Assign values to the corresponding variables based on the key
                    switch (key) {
                        case "type":
                            type = value;
                            break;
                        case "symbol":
                            symbol = value;
                            break;
                        case "name":
                            name = value;
                            break;
                        case "quantity":
                            quantity = Integer.parseInt(value);
                            break;
                        case "price":
                            price = Double.parseDouble(value);
                            break;
                        case "bookValue":
                            bookValue = Double.parseDouble(value);
                            break;
                    }

                } else if (line.isEmpty() && !type.isEmpty()) {
                    // Create and add an investment if line is empty and type is set
                    Investment currentInvestment = null;
                    if (type.equals("stock")) {
                        currentInvestment = new Stock(symbol, name, quantity, price, bookValue);
                    } else if (type.equals("mutualfund")) {
                        currentInvestment = new MutualFund(symbol, name, quantity, price, bookValue);
                    }
                    // Add the created investment to the portfolio
                    if (currentInvestment != null) {
                        investments.add(currentInvestment);
                        addToNameIndex(name, investments.size() - 1);
                        System.out.println("Loaded investment: " + currentInvestment); // Debugging print statement
                    }

                    // Reset for the next investment
                    type = "";
                    symbol = "";
                    name = "";
                    quantity = 0;
                    price = 0.0;
                    bookValue = 0.0;
                }
            }

            // Ensure the last investment is added if file doesn't end with a blank line
            if (!type.isEmpty()) {
                Investment currentInvestment = null;
                if (type.equals("stock")) {
                    currentInvestment = new Stock(symbol, name, quantity, price, bookValue);
                } else if (type.equals("mutualfund")) {
                    currentInvestment = new MutualFund(symbol, name, quantity, price, bookValue);
                }
                // adding the created investment to the portoflio
                if (currentInvestment != null) {
                    investments.add(currentInvestment);
                    addToNameIndex(name, investments.size() - 1);
                    System.out.println("Loaded investment: " + currentInvestment); // Debugging print statement
                }
            }

        } catch (FileNotFoundException e) {
            System.out.println("File wasn't found: " + fileName);
        }
    }

    /**
     * saves the current portoflio of investments to a specific file
     *
     * @param fileName the name of the file containing investment data
     */
    private void saveFromFile(String fileName) {
        try (PrintWriter writing = new PrintWriter(new FileWriter(fileName))) {
            // Iterate over each investment in the portfolio
            for (Investment investing : investments) {
                // Determine the type of investment (stock or mutual fund)
                String instance;
                if (investing instanceof MutualFund) {
                    instance = "mutualfund";
                } else {
                    instance = "stock";
                }
                writing.println("type = \"" + instance + "\"");

                // Write the remaining investment details
                writing.println("symbol = \"" + investing.getSymbol() + "\"");
                writing.println("name = \"" + investing.getName() + "\"");
                writing.println("quantity = \"" + investing.getQuantity() + "\"");
                writing.println("price = \"" + String.format("%.2f", investing.getPrice()) + "\"");
                writing.println("bookValue = \"" + String.format("%.2f", investing.getBookValue()) + "\"");

                // Add blank line between investments
                writing.println();
            }
        } catch (IOException e) {
            System.out.println("Error writing to file: " + fileName);
        }
    }

    // Task 1: Buying method: Check if the investment exists, update or create new
    /**
     * Buys an investment (Stock or MutualFund) from the portfolio.
     * 
     * @param scanner Scanner object to read user input
     */
    public void buyInvestment(Scanner scanner) {
        // prompting user for stock and mutualfund choice
        System.out.println("Enter the type of investment you'd like to choose (Stock, MutualFund): ");
        String investmentChoice = scanner.nextLine().toLowerCase();

        // prompting user for investment symbol
        System.out.println("Enter the symbol of your investment: ");
        String investmentSymbol = scanner.nextLine().toUpperCase();

        // checking if an investment with the same symbol already exists
        for (Investment investment : investments) {
            if (investment.getSymbol().equals(investmentSymbol)) {
                System.out.println("An investment with this symbol already exists.");
                return; // Exit the method to prevent adding a duplicate
            }
        }
        // If it's a new investment, get the new name of the investment
        System.out.println("Enter the new name of the investment: ");
        String name = scanner.nextLine().trim();

        // Prompt for quantity and price
        System.out.println("Enter the quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // consume newline

        System.out.println("Enter the price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // consume newline

        // validating the price and quantity inputs
        if (quantity <= 0 || price <= 0) {
            System.out.println("The price and quantity have to be positive values.");
            return;
        }

        // Add new investment
        Investment brandNewInvestment;
        if (investmentChoice.equals("stock")) {
            brandNewInvestment = new Stock(investmentSymbol, name, quantity, price, 0.0);
        } else if (investmentChoice.equals("mutualfund")) {
            brandNewInvestment = new MutualFund(investmentSymbol, name, quantity, price, 0.0);
        } else {
            System.out.println("Invalid investment type, please enter 'stock' or 'mutualfund'.");
            return;
        }
        brandNewInvestment.calculateBookValue();
        investments.add(brandNewInvestment);
        // updating the position? after adding the investent to arraylist
        int newPosition = investments.size() - 1;
        addToNameIndex(brandNewInvestment.getName(), newPosition);

        System.out.println("Added new investment: " + brandNewInvestment);
    }

    // Methods for storing the positions of investments in arraylist
    // method to add investment to index
    /**
     * Adds keywords from the investment name to the name index, mapping each
     * keyword
     * to the position of the investment in the list.
     *
     * @param name     the name of the investment
     * @param position the position of the investment in the list
     */
    private void addToNameIndex(String name, int position) {
        // Split the name into individual keywords
        String[] keywords = name.toLowerCase().split("\\s+");

        // Iterate through each keyword
        for (String keyword : keywords) {
            // Retrieve the list of positions for the keyword or create a new list if not
            // present
            ArrayList<Integer> positions = nameIndex.getOrDefault(keyword, new ArrayList<>());
            // Add the current position to the list
            positions.add(position);
            // Update the map with the new list of positions
            nameIndex.put(keyword, positions);
        }
    }

    // Method to update positions after deletion
    /**
     * Updates all positions in the name index to account for a deleted investment.
     *
     * @param deletedPosition the position of the investment that was deleted
     */
    private void updatePositionsAfterDeletion(int deletedPosition) {
        // Iterate through all position lists in the name index
        for (ArrayList<Integer> positions : nameIndex.values()) {
            // removing the deleted position from the list
            positions.removeIf(pos -> pos == deletedPosition);
            for (int i = 0; i < positions.size(); i++) {
                if (positions.get(i) > deletedPosition) {
                    positions.set(i, positions.get(i) - 1);
                }
            }
        }
        // Remove any empty lists
        nameIndex.entrySet().removeIf(entry -> entry.getValue().isEmpty());
    }

    // Task 2: Selling Investments: Check if investment exists and has enough
    // quantity
    /**
     * Sells an investment (Stock or MutualFund) from the portfolio.
     * 
     * @param scanner Scanner object to read user input
     */
    public void sellInvestment(Scanner scanner) {
        // prompting user for investment
        System.out.println("Enter the investment symbol you'd like to sell: ");
        String investmentSymbol = scanner.nextLine().toUpperCase().trim();

        // prompt for price and quantity below
        System.out.println("Enter the price: ");
        double price = scanner.nextDouble();
        System.out.println("Enter the quantity: ");
        int quantity = scanner.nextInt();

        scanner.nextLine(); // consume new line

        // Validate the inputs
        if (quantity <= 0 || price <= 0) {
            System.out.println("Quantity and price must be positive values.");
            return;
        }

        boolean investmentFound = false;
        // looping through the investments to find the matching one
        for (Investment investment : investments) {
            System.out.println("Checking investment: " + investment.getSymbol()); // Debugging print statement
            if (investment.getSymbol().equals(investmentSymbol)) {
                investmentFound = true;

                // making sure the investment has enough quantity to sell
                if (investment.getQuantity() >= quantity) {
                    // Calculate payment received and gain/loss using subclass methods
                    double saleProceeds;
                    if (investment instanceof Stock) {
                        saleProceeds = price * quantity - 9.99; // comission fee
                    } else {
                        saleProceeds = price * quantity - 45.00; // fee for mutualfund
                    }

                    // calculating bookvalue
                    double bookValueSold = investment.getBookValue() * ((double) quantity / investment.getQuantity());
                    // calculate gain and loss
                    double gainLoss = saleProceeds - bookValueSold;

                    System.out.printf("Sale Proceeds (Payment): %.2f%n", saleProceeds);
                    System.out.printf("Gain/Loss: %.2f%n", gainLoss);

                    // updating the quantity and the bookvalue
                    investment.setQuantity(investment.getQuantity() - quantity);
                    if (investment.getQuantity() > 0) {
                        double remainingQuantity = investment.getQuantity();
                        investment.setBookValue(
                                (investment.getBookValue() * remainingQuantity) / (remainingQuantity + quantity));
                    } else {
                        int position = investments.indexOf(investment);
                        investments.remove(investment);
                        // removing the keyword from the hasmap
                        updatePositionsAfterDeletion(position);

                        System.out.println("Investment has been completely sold and removed from the portfolio.");
                    }
                    System.out.printf("Updated Quantity after sale: %d%n", investment.getQuantity());

                } else {
                    System.out.println("Insufficient amount of quantity for sale.");
                }
                break;
            }
        }
        // if the investment that the user is trying to sell isnt found, then we handle
        // that here
        if (!investmentFound) {
            System.out.println("Investment not found.");
        }
    }

    /**
     * Updates an investment (Stock or MutualFund) from the portfolio.
     * 
     * @param scanner Scanner object to read user input
     */
    // Task 3: Updating prices: Go through all investments and update prices
    public void updateInvestment(Scanner scanner) {
        if (investments.isEmpty()) {
            System.out.println("No investments to update");
            return;
        }

        System.out.println("---Updating the investments---");
        for (Investment investment : investments) {
            try {
                System.out.printf("Enter the new price of the investment for %s: ", investment.getSymbol());
                double newPrice = scanner.nextDouble();
                scanner.nextLine(); // Consume newline

                // Update the price using the polymorphic method
                investment.updatePrice(newPrice);
                investment.calculateBookValue();

                System.out.println("Updated investment: " + investment);
            } catch (Exception e) {
                System.out.println("An error occurred while updating investment: " + e.getMessage());
            }
        }
    }

    /**
     * Computes the total sum of our gain of an investment by accumulating the gains
     * of all investments (Stock or MutualFund) from the portfolio.
     * 
     */
    public void getGain() {
        System.out.println("---Computing total gain of all investments in Portfolio---");
        double totalGain = 0.0;

        for (Investment investment : investments) {
            double currentPrice = investment.getPrice();
            double quantity = investment.getQuantity();
            double bookValue = investment.getBookValue();
            double currentValue = currentPrice * quantity;

            double gain;

            if (investment instanceof Stock) {
                // Stock-specific calculations, including any fees if necessary
                gain = currentValue - bookValue; // No additional fees for gain calculation here
            } else if (investment instanceof MutualFund) {
                // MutualFund-specific calculations, including any fees if necessary
                gain = currentValue - bookValue; // No additional fees for gain calculation here
            } else {
                System.out.println("Unknown investment type: " + investment.getClass().getSimpleName());
                continue;
            }

            totalGain += gain;
        }

        System.out.printf("The total sum of our gains for all investments in portfolio: $%.2f%n", totalGain);
    }

    /**
     * @param scanner Scanner object to read user input
     *                Searches for investments based on user-provided criteria.
     *                The user can enter values for up to three fields: symbol,
     *                keywords for the name, and a price range.
     */

    public void searchInvestment(Scanner scanner) {
        System.out.println("Enter the search criteria below.");

        System.out.println("Enter the symbol: ");
        String symbolInput = scanner.nextLine().trim().toUpperCase();

        System.out.println("Enter the keywords: ");
        String keywordSearch = scanner.nextLine().trim().toLowerCase();

        System.out.println("Price range (min max): ");
        String priceRange = scanner.nextLine().trim();

        ArrayList<Investment> results = new ArrayList<>(investments);

        // Search by keywords using nameIndex
        if (!keywordSearch.isEmpty()) {
            String[] keywords = keywordSearch.split("\\s+");
            Set<Integer> matchedPositions = new HashSet<>();

            for (String keyword : keywords) {
                ArrayList<Integer> positions = nameIndex.get(keyword);
                if (positions != null) {
                    if (matchedPositions.isEmpty()) {
                        matchedPositions.addAll(positions);
                    } else {
                        matchedPositions.retainAll(positions);
                    }
                }
            }
            // Filter results based on matched positions
            if (!matchedPositions.isEmpty()) {
                results.removeIf(investment -> !matchedPositions.contains(investments.indexOf(investment)));
            } else {
                results.clear(); // No matches found for keywords
            }
        }

        // Filter by symbol if provided
        if (!symbolInput.isEmpty()) {
            results.removeIf(investment -> !investment.getSymbol().equalsIgnoreCase(symbolInput));
        }

        // Filter by price range if provided
        if (!priceRange.isEmpty()) {
            String[] range = priceRange.split("\\s+");
            if (range.length == 2) {
                try {
                    double minPrice = Double.parseDouble(range[0]);
                    double maxPrice = Double.parseDouble(range[1]);
                    results.removeIf(
                            investment -> investment.getPrice() < minPrice || investment.getPrice() > maxPrice);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid price range format.");
                }
            }
        }

        // Display the results
        if (results.isEmpty()) {
            System.out.println("No matching investments were found.");
        } else {
            for (Investment investment : results) {
                System.out.println(investment);
            }
        }
    }
}
